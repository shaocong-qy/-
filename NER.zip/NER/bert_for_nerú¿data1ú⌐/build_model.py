#! -*- coding: utf-8 -*-
import keras
import keras.backend
import keras.backend.numpy_backend
from bert4keras.models import build_transformer_model
from bert4keras.optimizers import Adam
from bert4keras.layers import ConditionalRandomField
import keras.backend as K


class SetLearningRate:
    """层的一个包装，用来设置当前层的学习率
    """
    def __init__(self, layer, lamb, is_ada=False):
        self.layer = layer
        self.lamb = lamb  # 学习率比例
        self.is_ada = is_ada  # 是否自适应学习率优化器

    def __call__(self, inputs):
        with K.name_scope(self.layer.name):
            if not self.layer.built:
                input_shape = K.int_shape(inputs)
                self.layer.build(input_shape)
                self.layer.built = True
                if self.layer._initial_weights is not None:
                    self.layer.set_weights(self.layer._initial_weights)
        for key in ['kernel', 'bias', 'embeddings', 'depthwise_kernel', 'pointwise_kernel', 'recurrent_kernel', 'gamma',
                    'beta']:
            if hasattr(self.layer, key):
                weight = getattr(self.layer, key)
                if self.is_ada:
                    lamb = self.lamb  # 自适应学习率优化器直接保持lamb比例
                else:
                    lamb = self.lamb ** 0.5  # SGD（包括动量加速），lamb要开平方
                K.set_value(weight, K.eval(weight) / lamb)  # 更改初始化
                setattr(self.layer, key, weight * lamb)  # 按比例替换
        return self.layer(inputs)

def bert_bilstm_crf(config_path, checkpoint_path, num_labels, lstm_units, drop_rate, learning_rate):
    bert = build_transformer_model(  # 加载bert
        config_path=config_path,  # 这些参数都是bert4keras包里面的
        checkpoint_path=checkpoint_path,
        model='bert',  # 加载的模型是bert
        return_keras_model=False
    )
    x = bert.model.output  # [batch_size, seq_length, 768] #拿到bert的输出、

    lstm = SetLearningRate(
            keras.layers.Bidirectional(  # 这样就是双向的
                keras.layers.LSTM(  # 这个是单向的LSTM
                    lstm_units,
                    kernel_initializer='he_normal',
                    return_sequences=True
                )
            ),
            100,
            True
         )(x)

    # 将两个输出结合，拼接的维度是-1
    x = keras.layers.concatenate(
        [lstm, x],
        axis=-1
    )  # [batch_size, seq_length, lstm_units * 2 + 768]

    x = keras.layers.TimeDistributed(
        keras.layers.Dropout(drop_rate)
    )(x)  # [batch_size, seq_length, lstm_units * 2 + 768]

    x = SetLearningRate(
        keras.layers.TimeDistributed(
            keras.layers.Dense(  # 降维
                num_labels,  # 这是标签的数量
                activation='relu',  # 激活函数
                kernel_initializer='he_normal',
            )
        ),
        100,
        True
    )(x)  # [batch_size, seq_length, num_labels]

    crf = ConditionalRandomField()
    output = crf(x)  # 模型的输出，在crf层之后

    model = keras.models.Model(bert.input, output)  # 这样模型就构建好了，输入是bert的input，输出就是crf以后的output
    model.summary()
    model.compile(
        loss=crf.sparse_loss,  # 使用crf的损失函数
        optimizer=Adam(learning_rate),  # 优化器
        metrics=[crf.sparse_accuracy]  # 评价指标用crf里面的指标
    )

    return model, crf  # 返回模型和crf


if __name__ == '__main__':  # main函数，用来配置参数
    config_path = 'D:/code/publish/bert_config.json'
    checkpoint_path = 'D:/code/publish/bert_model.ckpt'
    num_labels = 21
    lstm_units = 128
    drop_rate = 0.1
    learning_rate = 1e-5
    model, crf = bert_bilstm_crf(config_path, checkpoint_path, num_labels, lstm_units, drop_rate, learning_rate)  # 加载模型
    print(model.summary())
