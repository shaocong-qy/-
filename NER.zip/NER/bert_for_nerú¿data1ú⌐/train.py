#! -*- coding: utf-8 -*-
import os
import sys
import random
import pickle
import numpy as np
from tqdm import tqdm
import tensorflow as tf
from bert4keras.backend import K,keras,search_layer
from bert4keras.snippets import ViterbiDecoder, to_array

from data_utils import *
from build_model import bert_bilstm_crf

import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"


#固定随机种子
seed = 233
tf.set_random_seed(seed)
np.random.seed(seed)
random.seed(seed)
os.environ['PYTHONHASHSEED'] = str(seed)

#设置超参数
epochs = 4
max_len = 70
batch_size = 32
lstm_units = 128
drop_rate = 0.1
learning_rate = 1e-5  # 初始学习速率时0.1


#bert模型初始化文件以及模型的保存路径，把训练后的模型进行保存
config_path = 'D:/code/publish/bert_config.json'
checkpoint_path = 'D:/code/publish/bert_model.ckpt'
checkpoint_save_path = './checkpoint/bert_bilstm_crf.weights'

class NamedEntityRecognizer(ViterbiDecoder):  #命名实体识别器
    """命名实体识别器
    """
    def recognize(self, text):
        tokens = tokenizer.tokenize(text)
        while len(tokens) > max_len:
            tokens.pop(-2)
        mapping = tokenizer.rematch(text, tokens)
        token_ids = tokenizer.tokens_to_ids(tokens)
        segment_ids = [0] * len(token_ids)
        token_ids, segment_ids = to_array([token_ids], [segment_ids]) # ndarray
        nodes = model.predict([token_ids, segment_ids])[0] # [sqe_len,23]
        labels = self.decode(nodes)# id [sqe_len,], [0 0 0 0 0 7 8 8 0 0 0 0 0 0 0]
        entities, starting = [], False
        for i, label in enumerate(labels):
            if label > 0:
                if label % 2 == 1:
                    starting = True
                    entities.append([[i], id2label[(label - 1) // 2]])
                elif starting:
                    entities[-1][0].append(i)
                else:
                    starting = False
            else:
                starting = False
        return [(text[mapping[w[0]][0]:mapping[w[-1]][-1] + 1], l) for w, l in entities]
#改进1
def ner_metrics(data): #把这个评价函数作为监控指标  把监控指标和评价指标进行统一
    X,Y,Z = 1e-6,1e-6,1e-6
    for d in tqdm(data):
        text = ''.join([i[0] for i in d])
        pred = NER.recognize(text)
        R = set(pred)
        T = set([tuple(i) for i in d if i[1] != 'o'])
        X += len(R & T)
        Y += len(R)
        Z += len(T)
    f1, precision, recall = 2 * X / (Y + Z), X/Y, X/Z  #最后主要看f1
    return f1, precision, recall

class Evaluator(keras.callbacks.Callback):
    def __init__(self):
        super(Evaluator,self).__init__()
        self.best_val_f1 = 0
    def on_epoch_end(self,epoch,logs=None):
        NER.trans = K.eval(CRF.trans)
        f1, precision, recall = ner_metrics(valid_data)
        if f1 > self.best_val_f1:
            model.save_weights(checkpoint_save_path)
            self.best_val_f1 = f1
            print('save model to {}'.format(checkpoint_save_path))
        else: #学习率衰减策略
            global learning_rate
            lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
                initial_learning_rate=5e-5,
                decay_steps=10000,
                decay_rate=0.96)
            learning_rate = tf.keras.optimizers.Adam(learning_rate=lr_schedule)

        print(
            'valid:  f1: %.5f, precision: %.5f, recall: %.5f, best f1: %.5f\n' %
            (f1, precision, recall, self.best_val_f1)
        )
# 改进
# -------------------------对抗训练
def adversarial_training(model, embedding_name, epsilon=1):
    """给模型添加对抗训练
    其中model是需要添加对抗训练的keras模型，embedding_name
    则是model里边Embedding层的名字。要在模型compile之后使用。
    """
    if model.train_function is None:  # 如果还没有训练函数
        model._make_train_function()  # 手动make
    old_train_function = model.train_function  # 备份旧的训练函数

    # 查找Embedding层
    for output in model.outputs:
        embedding_layer = search_layer(output, embedding_name)
        if embedding_layer is not None:
            break
    if embedding_layer is None:
        raise Exception('Embedding layer not found')

    # 求Embedding梯度
    embeddings = embedding_layer.embeddings  # Embedding矩阵
    gradients = K.gradients(model.total_loss, [embeddings])  # Embedding梯度
    gradients = K.zeros_like(embeddings) + gradients[0]  # 转为dense tensor

    # 封装为函数
    inputs = (model._feed_inputs +
              model._feed_targets +
              model._feed_sample_weights)  # 所有输入层
    embedding_gradients = K.function(
        inputs=inputs,
        outputs=[gradients],
        name='embedding_gradients',
    )  # 封装为函数

    def train_function(inputs):  # 重新定义训练函数
        grads = embedding_gradients(inputs)[0]  # Embedding梯度
        delta = epsilon * grads / (np.sqrt((grads**2).sum()) + 1e-8)  # 计算扰动
        K.set_value(embeddings, K.eval(embeddings) + delta)  # 注入扰动
        outputs = old_train_function(inputs)  # 梯度下降
        K.set_value(embeddings, K.eval(embeddings) - delta)  # 删除扰动
        return outputs

    model.train_function = train_function  # 覆盖原训练函数
# ----------------------
model,CRF = bert_bilstm_crf(
        config_path,checkpoint_path,num_labels,lstm_units,drop_rate,learning_rate)
adversarial_training(model,'Embedding-Token',0.5)#对抗训练加的
NER = NamedEntityRecognizer(trans=K.eval(CRF.trans), starts=[0], ends=[0])

if __name__ == '__main__':

    train_data,_ = load_data('D:/bert_for_ner/data/train.conll',max_len)
    valid_data,_ = load_data('D:/bert_for_ner/data/dev.conll',max_len)

    train_generator = data_generator(train_data, batch_size)
    valid_generator = data_generator(valid_data, batch_size*5)

    checkpoint = keras.callbacks.ModelCheckpoint(
        checkpoint_save_path,
        monitor='val_sparse_accuracy',
        verbose=1,
        save_best_only=True,
        mode='max'
        )
    evaluator = Evaluator()
    model.fit(  #fit就是进行训练
        train_generator.forfit(),
        steps_per_epoch=len(train_generator),
        validation_data=valid_generator.forfit(),
        validation_steps=len(valid_generator),
        epochs=epochs,
        callbacks=[evaluator]
    )

    print(K.eval(CRF.trans))
    print(K.eval(CRF.trans).shape)
    pickle.dump(K.eval(CRF.trans),open('./checkpoint/crf_trans.pkl','wb'))#把crf矩阵进行保存

else:
    model.load_weights(checkpoint_save_path)
    NER.trans = pickle.load(open('./checkpoint/crf_trans.pkl','rb'))

